***** lab7 *****
 in terminal

1. javac Test.java
2. java Test